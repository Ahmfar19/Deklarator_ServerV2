const { validationResult } = require('express-validator');
const User = require('../models/user.model');
var jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');
const { sendEmail } = require('./sendEmail.controller')
const { hashPassword, comparePassword } = require('../helpers/utils');
const { sendResponse } = require('../helpers/apiResponse');
const mailMessags = require('../helpers/emailMessages');

 


function searchImageByName(directoryPath, imageName) {
    const imageNameWithoutExtension = path.parse(imageName).name;

    return new Promise((resolve, reject) => {
        fs.readdir(directoryPath, (err, files) => {
            if (err) {
                reject(err);
                return;
            }
            const foundImage = files.find(file => {
                const fileNameWithoutExtension = path.parse(file).name;
                return fileNameWithoutExtension === imageNameWithoutExtension;
            });
            if (foundImage) {
                const imagePath = path.join(directoryPath, foundImage);
                resolve(imagePath);
            } else {
                resolve(null); // Image not found
            }
        });
    });
}

async function uploadImage(file, userID) {
    const tempPath = file.path;
    const fileExtension = path.extname(file.originalname);
    const newFileName = `user_${userID}${fileExtension}`;
    const uploadPath = "assets/images/users"
    const targetPath = path.join(uploadPath, newFileName);

    try {
        const foundImage = await searchImageByName(uploadPath, newFileName);
        // Remove any existing image for this user before uploading the new image
        if (foundImage) {
            fs.unlinkSync(foundImage);
        }

        fs.renameSync(tempPath, targetPath);
        return targetPath.replace(/\\/g, '/');
    } catch (error) {
        throw new Error('Error uploading image:', error);
    }
}

const createUser = async (req, res) => {

    try {
        const { username, fname, lname, phone, email, role, password } = req.body
        const checkUser = await User.checkIfUserExisted(email, username)

        if (checkUser.length) {
            return res.status(406).send({
                statusCode: 406,
                statusMessage: ' Not Acceptable',
                message: 'user already existed.',
            });
        }

        const errors = validationResult(req);

        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() })
        }

        const hashedPassword = await hashPassword(password);

        if (!hashedPassword) {
            throw new Error("Password error");
        }

        const user = new User({
            username,
            fname,
            lname,
            phone,
            email,
            role,
            password: hashedPassword,
        });

        await user.createUser();

        res.status(201).send({
            statusCode: 201,
            statusMessage: 'Created',
            message: 'Successfully created a user.',
            data: user,
        });
        const title = mailMessags.loginMessage.title.replace('{0}', username);
        const body = mailMessags.loginMessage.body.replace('{0}', username).replace('{1}', password);
        sendEmail(email, title, body);

    } catch (err) {

        res.status(500).send({
            statusCode: 500,
            statusMessage: 'Internal Server Error',
            message: null,
            data: null,
            error: err.message || err
        });
    }
}

const getUsers = async (req, res) => {
    try {
        const users = await User.getAllUsers();
        res.send({
            statusCode: 200,
            statusMessage: 'Ok',
            message: 'Successfully retrieved all the users.',
            data: users,
        });
    } catch (err) {
        res.status(500).send({
            statusCode: 500,
            statusMessage: 'Internal Server Error',
            message: null,
            data: null,
            error: err.message || err
        });
    }
};

const getSingleUser = async (req, res) => {
    try {
        const id = req.params.id;
        const singleUser = await User.getUserById(id)
        res.send({
            statusCode: 200,
            statusMessage: 'Ok',
            message: 'Successfully retrieved the single user.',
            data: singleUser,
        });
    } catch (err) {
        res.status(500).send({
            statusCode: 500,
            statusMessage: 'Internal Server Error as',
            message: null,
            data: null,
            error: err.message || err
        });
    }

};

const updateUser = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() })
        }

        const userData = req.body;
        const id = req.params.id;

        if (req.file) {
            const imagePath = await uploadImage(req.file, id);
            userData.image = imagePath;
        }

        const user = new User(userData);
        await user.updateUser(id);

        return res.status(202).send({
            statusCode: 202,
            statusMessage: 'Accepted',
            message: 'Successfully updated a user.',
            data: null,
        });
    } catch (err) {
        res.status(500).send({
            statusCode: 500,
            statusMessage: 'Internal Server Error',
            message: null,
            data: null,
            error: err.message || err
        });
    }
};

const updateUserPassword = async (req, res) => {
    const id = req.params.id;
    const { password, new_password, verify_password } = req.body;

    try {

        if (new_password !== verify_password) {
            throw new Error("Passwords do not match");
        }

        const user = await User.getUserById(id);

        if (!user.length) {
            throw new Error("The user does not exist");
        }

        const match = await comparePassword(password, user[0].password);

        if (match !== true) {
            throw new Error("Current password does not match");
        }

        const newPaawordHash = await hashPassword(new_password);

        await User.updatePassword(id, newPaawordHash);

        res.send({
            statusCode: 200,
            statusMessage: 'Ok',
            message: 'Successfully update the password',
            data: null,
        });
    }
    catch (err) {
        res.status(500).send({
            statusCode: 500,
            statusMessage: 'Internal Server Error',
            message: null,
            data: null,
            error: err.message || err
        });
    }
};

const deleteUser = async (req, res) => {
    const id = req.params.id;
    try {
        const data = await User.deleteUser(id);
        res.send({
            statusCode: 200,
            statusMessage: 'Ok',
            message: 'Successfully deleted a user.',
            data: data,
        });
    }
    catch (err) {
        res.status(500).send({
            statusCode: 500,
            statusMessage: 'Internal Server Error as',
            message: null,
            data: null,
            error: err.message || err
        });
    }
};

const login = async (req, res) => {
    const { email_username, password, rememberMe, fingerprint } = req.body;

    try {
        const data = await User.loginUser(email_username);
        if (data.length > 0) {

            const match = await comparePassword(password, data[0].password);

            if (match) {
                const expiresIn = rememberMe ? "30d" : "1d";
                const finger_print = fingerprint + String(data[0].staff_id)
                const token = jwt.sign({ id: finger_print }, process.env.JWT_SECRET_KEY, { expiresIn });
                const serverCookiesAge = rememberMe ? (3600000 * 24 * 30) : 3600000

                res.cookie('accessToken', token, {
                    httpOnly: true,
                    secure:true,
                    maxAge: serverCookiesAge
                });
                
                res.json({
                    user: data[0],
                    authenticated: true,
                    accessToken: token
                });

                return res;

            } else {
                return res.json({ error: "Password or Email is incorrect" });
            }
        } else {
            return res.json({ error: "User does not exist in the database" });
        }
    } catch (error) {
        return res.status(500).json({ error: "Internal Server Error" });
    }
}

const verifyToken = async (req, res) => {

     const { user_id, fingerprint } = req.body;

    try {

        if (req?.headers?.authorization?.startsWith('Bearer')) {
            let token = req.headers.authorization.split(" ")[1]

            if (token) {
                const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY);
                const checkUserDevice = fingerprint + user_id

                if(checkUserDevice === decoded.id){
                    return res.status(200).send({
                        statusCode: 200,
                        authenticated: true,                  
                    });

                }else {
                    return res.status(401).send({
                        statusCode: 401,
                        authenticated: false,                                 
                    });
                }   

            } else {
                throw new Error('not authenticated') 
            }
      
        } else {
            throw new Error('there is no token attached to headers')
        }
  
    } catch (err) {

        sendResponse(res, 500, 'Internal Server Error', null, err.message || err, null);
    }
}
module.exports = {
    createUser,
    getUsers,
    getSingleUser,
    updateUser,
    deleteUser,
    updateUserPassword,
    login,
    verifyToken
};

