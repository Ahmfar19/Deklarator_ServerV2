const Company = require('../models/company.model');
const { sendResponse } = require('../helpers/apiResponse');



const getSingleCompany = async (req, res) => {
    try {
        const id = req.params.id;
        const singleCompany = await Company.getCompany(id)
        sendResponse(res, 200, 'Ok', 'Successfully retrieved  the company', null, singleCompany);
    } catch (err) {
        sendResponse(res, 500, 'Internal Server Error', null, err.message || err, null);
    }

};
const getCompanys = async (req, res) => {
    try {
        const companys = await Company.getAll();
        sendResponse(res, 200, 'Ok', 'Successfully retrieved all the company', null, companys);
    } catch (err) {
        sendResponse(res, 500, 'Internal Server Error', null, err.message || err, null);
    }
};
const addCompany = async (req, res) => {
    try {
        const company = new Company(req.body);
        const isValid = company.isValid();
        if (!isValid) {
            return res.status(400).send(
                { statusCode: 400, statusMessage: 'Bad Request', message: null, data: null }
            );
        }
        await company.save();
        sendResponse(res, 201, 'Created', 'Successfully created a company.', null, company);

    } catch (err) {
        sendResponse(res, 500, 'Internal Server Error', null, err.message || err, null);
    }
};
const updateCompany = async (req, res) => {
    try {
        const id = req.params.id;
        const company = new Company(req.body);
        const checkCompany = await Company.checkIfCompanyExisted(id)
        if (checkCompany.length == 0) {
            return res.status(404).send({
                statusCode: 404,
                statusMessage: 'Not Found',
                message: 'No company found for update',
                data: null,
            });
        }
        const isValid = company.isValid();
        if (!isValid) {
            return res.status(400).send(
                { statusCode: 400, statusMessage: 'Bad Request', message: "No valid request data", data: null }
            );
        }
        await company.updateCompany(id);
        sendResponse(res, 202, 'Accepted', 'Successfully updated a company.', null, company);
    } catch (err) {
        sendResponse(res, 500, 'Internal Server Error', null, err.message || err, null);
    }
};
const deleteCompany = async (req, res) => {
    try {
        const id = req.params.id;
        const checkCompany = await Company.checkIfCompanyExisted(id)
        if (checkCompany.length == 0) {
            return res.status(404).send({
                statusCode: 404,
                statusMessage: 'Not Found',
                message: 'No company found for delete',
                data: null,
            });
        }
        const data = await Company.findByIdAndDelete(id);
        sendResponse(res, 202, 'Accepted', 'Successfully deleted a company.', null, data);
    }
    catch (err) {
        sendResponse(res, 500, 'Internal Server Error', null, err.message || err, null);
    }
};

module.exports = {
    getCompanys,
    getSingleCompany,
    addCompany,
    updateCompany,
    deleteCompany,
};
