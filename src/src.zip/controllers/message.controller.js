

const getMessages = async (req, res) => {
   
}  

module.exports = {
    getMessages
}